# react_native_tete_dictionary

1..node_module changes:
library react-native-paystack-webview 
In Paystack.js
Line No. 131 
Add Props : onRequestClose 