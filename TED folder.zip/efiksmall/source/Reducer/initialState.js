
export default {
  apps: {
    theme: 'light',
    notificationCount: 0,

  },
};
