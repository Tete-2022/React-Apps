export default {
  // Poppins-
  Regular: 'Poppins-Regular',
  Bold: 'Poppins-Bold',
  Light: 'Poppins-Light',
  SemiBold: 'Poppins-SemiBold',
  ExtraBold: 'Poppins-ExtraBold',
  Medium: 'Poppins-Medium',
  Black: 'Poppins-Black',
  Italic: 'Poppins-Italic'
};
